ProPool URP 4K - Final Project Package (Debug-ready)
---------------------------------------------------

هذا الحزمة النهائية تحتوي على مشروع Unity جاهز للتطوير والرفع على Unity Cloud Build.
المحتويات هي بنية مشروع مع سكربتات جاهزة وـplaceholder textures عالية الدقة (2048x2048).
بعد فك الضغط: استورد مجلد 'Assets' داخل مشروع Unity جديد URP ثم اتبع تعليمات Build-Instructions-CloudBuild.md
