Build-Instructions for Unity Cloud Build (from Mobile)
1) Open https://dashboard.unity.com and sign in.
2) Create project -> DevOps -> Cloud Build -> New Build Target -> Upload a project (ZIP).
3) Upload this ZIP file. Configure platform Android, Build Type: Development, Target API Level: 31.
4) Save and press Build Now. Download APK from Artifacts when finished.
