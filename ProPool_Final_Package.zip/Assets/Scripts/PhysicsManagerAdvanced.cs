using UnityEngine;
public class PhysicsManagerAdvanced : MonoBehaviour {
    void Awake() { Time.fixedDeltaTime = 1f/120f; }
}