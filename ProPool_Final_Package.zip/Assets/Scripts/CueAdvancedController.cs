using UnityEngine;
public class CueAdvancedController : MonoBehaviour {
    public Rigidbody cueBallRb;
    public Transform cueVisual;
    public float maxPower = 6f;
    public float spinMultiplier = 0.8f;
    Vector2 dragStart; bool aiming = false;
    void Update() {
        if (Input.GetMouseButtonDown(0)) { dragStart = Input.mousePosition; aiming = true; }
        if (Input.GetMouseButtonUp(0) && aiming) { Vector2 dragEnd = Input.mousePosition; Vector2 diff = dragStart - dragEnd; Shoot(diff); aiming = false; }
    }
    void Shoot(Vector2 diff) {
        if (!cueBallRb) return;
        Vector3 dir = new Vector3(diff.x, 0, diff.y).normalized;
        float power = Mathf.Min(diff.magnitude / 200f, 1f) * maxPower;
        Vector3 impulse = new Vector3(dir.x, 0, dir.z) * power;
        var ballComp = cueBallRb.GetComponent<BallAdvanced>();
        if (ballComp != null) ballComp.ApplyCueHit(impulse, Vector3.right * 0.1f, spinMultiplier);
        else cueBallRb.AddForce(impulse, ForceMode.Impulse);
    }
}