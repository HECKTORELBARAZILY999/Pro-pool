using UnityEngine;
[RequireComponent(typeof(Rigidbody))]
public class BallAdvanced : MonoBehaviour {
    public int number = 0;
    public float radius = 0.028f;
    public float mass = 1f;
    Rigidbody rb;
    void Awake() {
        rb = GetComponent<Rigidbody>();
        rb.mass = mass;
        rb.collisionDetectionMode = CollisionDetectionMode.ContinuousDynamic;
    }
    public void ApplyCueHit(Vector3 impulse, Vector3 contactPointLocal, float spinFactor) {
        rb.AddForce(impulse, ForceMode.Impulse);
        Vector3 torque = Vector3.Cross(contactPointLocal.normalized * radius, impulse) * spinFactor * 0.1f;
        rb.AddTorque(torque, ForceMode.Impulse);
    }
    public void Pocket() { gameObject.SetActive(false); }
}