using UnityEngine;
public class GameManagerAdvanced : MonoBehaviour {
    public BallAdvanced cueBall;
    public int score = 0;
    void Start() {}
    public void OnBallPocketed(BallAdvanced b) { if (b.number>0) score++; Debug.Log("Score: "+score); }
}